#' @keywords internal
#' @import rlang
#' @importFrom dplyr across
#' @importFrom glue glue
"_PACKAGE"

## usethis namespace: start
## usethis namespace: end
NULL

utils::globalVariables(c("."))
