# add_q() errors with no p.value column

    Code
      add_q(table1)
    Condition
      Error in `add_q()`:
      ! There is no p-value column. `x$table_body` must have a column called "p.value".

