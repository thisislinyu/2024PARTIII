# remove_row_type(type) messaging

    Code
      remove_row_type(tbl_summary(trial, include = c(response, age, grade)), type = "reference")
    Condition
      Error in `remove_row_type()`:
      ! Column(s) "reference_row" are not present in `x$table_body`, and function cannot be used to remove these rows.

