# style_pvalue() messaging

    Code
      style_pvalue(0.05, digits = 8)
    Condition
      Error in `style_pvalue()`:
      ! The `digits` argument must be one of 1, 2, and 3.

