library(testthat)

test_check("flextable")
