coef.poLCA <-
function(object, ...) {
    return(object$coeff)
}
