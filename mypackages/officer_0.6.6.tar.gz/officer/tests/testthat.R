suppressPackageStartupMessages({
  library(testthat)
  library(officer)
  library(xml2)
})

test_check("officer")
