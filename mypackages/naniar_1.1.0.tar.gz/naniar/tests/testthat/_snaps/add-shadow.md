# add_shadow returns a nice error message when no variables are provided

    Code
      add_shadow(dat)
    Condition
      Error in `add_shadow()`:
      ! argument must be specified
      {.fun add_shadow} requires variables to be selected

