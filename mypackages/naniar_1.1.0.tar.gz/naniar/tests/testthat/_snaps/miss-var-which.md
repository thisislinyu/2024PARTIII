# miss-var-which errors on NULL

    Code
      miss_var_which(NULL)
    Condition
      Error in `miss_var_which()`:
      ! Input must inherit from <data.frame>
      We see class: <NULL>

