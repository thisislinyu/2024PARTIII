# cast_shadow_shift_label returns nice error if variables aren't included

    Code
      cast_shadow_shift(airquality)
    Condition
      Error in `cast_shadow()`:
      ! argument must be specified
      {.fun cast_shadow} requires variables to be selected after the data

