# miss_var_cumsum gives warning

    `miss_var_cumsum()` was deprecated in naniar 1.1.0.
    i Please use `miss_var_summary(data, add_cumsum = TRUE)`

# miss_var_cumsum gives warning with grouping

    `miss_var_cumsum()` was deprecated in naniar 1.1.0.
    i Please use `miss_var_summary(data, add_cumsum = TRUE)`

