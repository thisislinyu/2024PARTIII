# miss_var_prop is defunct

    Code
      miss_var_prop(df)
    Condition
      Error:
      ! 'miss_var_prop' is defunct.
      Use 'prop_miss_var' instead.
      See help("Defunct")

# complete_var_prop is defunct

    Code
      complete_var_prop(df)
    Condition
      Error:
      ! 'complete_var_prop' is defunct.
      Use 'prop_complete_var' instead.
      See help("Defunct")

# miss_var_pct is defunct

    Code
      miss_var_pct(df)
    Condition
      Error:
      ! 'miss_var_pct' is defunct.
      Use 'pct_miss_var' instead.
      See help("Defunct")

# complete_var_pct is defunct

    Code
      complete_var_pct(df)
    Condition
      Error:
      ! 'complete_var_pct' is defunct.
      Use 'pct_complete_var' instead.
      See help("Defunct")

# miss_case_prop is defunct

    Code
      miss_case_prop(df)
    Condition
      Error:
      ! 'miss_case_prop' is defunct.
      Use 'prop_miss_case' instead.
      See help("Defunct")

# complete_case_prop is defunct

    Code
      complete_case_prop(df)
    Condition
      Error:
      ! 'complete_case_prop' is defunct.
      Use 'prop_complete_case' instead.
      See help("Defunct")

# miss_case_pct is defunct

    Code
      miss_case_pct(df)
    Condition
      Error:
      ! 'miss_case_pct' is defunct.
      Use 'pct_miss_case' instead.
      See help("Defunct")

# complete_case_pct is defunct

    Code
      complete_case_pct(df)
    Condition
      Error:
      ! 'complete_case_pct' is defunct.
      Use 'pct_complete_case' instead.
      See help("Defunct")

# replace_to_na is defunct

    Code
      replace_to_na(df)
    Condition
      Error:
      ! 'replace_to_na' is defunct.
      Use 'replace_with_na' instead.
      See help("Defunct")

