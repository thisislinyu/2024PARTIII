# cast_shadow_shift returns nice error when variables aren't included

    Code
      cast_shadow_shift(airquality)
    Condition
      Error in `cast_shadow()`:
      ! argument must be specified
      {.fun cast_shadow} requires variables to be selected after the data

